
package launcher;

import model.ShannonsTheorem;
import view.ShannonsPresenter;
import view.ShannonsView;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author vthan
 */
public class ShannonsLaunch extends Application {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Application.launch(args);
    }
    
    @Override
    public void start(Stage stage){
        ShannonsTheorem model = new ShannonsTheorem();
        ShannonsView view = new ShannonsView();
        
        Scene scene = new Scene(view);
        
        ShannonsPresenter presenter = new ShannonsPresenter(model, view);
        
        stage.setScene(scene);
        stage.setTitle("Shannon's Theorem");
        stage.show();
    }
}
