package model;

import java.util.List;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.DoubleProperty;

/**
 * class that implements "model" for an MVC application that calculates Shannon's Theorem
 * @author kriger, yapt
 */
public class ShannonsTheorem {
    private final DoubleProperty bandWidth = new SimpleDoubleProperty(this, "bandWidth", 0.0);
    private final DoubleProperty signalPower = new SimpleDoubleProperty(this, "signalPower", 0.0);
    private final DoubleProperty noisePower = new SimpleDoubleProperty(this, "noisePower", 0.0);
    
    /**
     * no-arg constructor sets fields to zero
     */
    public ShannonsTheorem() {
	this(0.0, 0.0, 0.0);
    }
    
    /**
     * multi-argument constructor
     * @param bandWidth the bandwidth in hertz
     * @param signalPower signal power in watts
     * @param noisePower noise power in watts
     */
    public ShannonsTheorem(double bandWidth, double signalPower, double noisePower) {
        this.bandWidth.set(bandWidth);
        this.signalPower.set(signalPower);
        this.noisePower.set(noisePower);
    }
    
    /**
     * @return the bandWidth
     */
    public final Double getBandWidth() {
    	return bandWidth.get();
    }
    /**
     * @param bandWidth the bandWidth to set
     */
    public final void setBandWidth(double bandWidth) {
        bandWidthProperty().set(bandWidth);
    }
    public final DoubleProperty bandWidthProperty(){
        return bandWidth;
    }
    
    /**
     * @return the signal power
     */
    public final Double getSignalPower() {
    	return signalPower.get();
    }
    /**
     * @param signalPower the signal power to set
     */
    public final void setSignalPower(double signalPower) {
	signalPowerProperty().set(signalPower);
    }
    public final DoubleProperty signalPowerProperty(){
        return signalPower;
    }
    
    /**
     * @return the noise power
     */
    public final double getNoisePower() {
	return noisePower.get();
    }
    /**
     * @param noisePower the noise power to set
     */
    public void setNoisePower(double noisePower) {
	noisePowerProperty().set(noisePower);
    }
    public final DoubleProperty noisePowerProperty(){
        return noisePower;
    }
	
    private double log2(double x) {
	return Math.log(x)/Math.log(2);
    }
	
    /**
     * @param bw the bandwidth
     * @param sp the signal power
     * @param np the noise power
     * @return maximum data rate
     */
    public final DoubleProperty maxDataRate(DoubleProperty bw, DoubleProperty sp, DoubleProperty np) {
        return bw * log2(1 + sp / np);
    }
	
    /**
     * @return maximum data rate
     */
    public final DoubleProperty maxDataRate() {
        return maxDataRate(bandWidth, signalPower, noisePower); // ? Potential bug/error
    }
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */

    /**
     * @return string for output
     */
    @Override
    public String toString() {
	return "ShannonsTheory [bandWidth=" + bandWidth + ", signalPower=" + signalPower + ", noisePower=" + noisePower + "]";
    }
    
    /*
     * Domain specific business rule. 
     */
    public boolean save(){
        System.out.println("Saved " + this.toString());
        return true;
    }
}
