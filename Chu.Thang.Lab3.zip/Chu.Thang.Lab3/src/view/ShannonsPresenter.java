/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import model.ShannonsTheorem;

import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author vthan
 */
public class ShannonsPresenter {
    
    private final ShannonsTheorem model;
    private final ShannonsView view;
    
    private final SimpleDoubleProperty bandWidthInternal = new SimpleDoubleProperty();
    private final SimpleDoubleProperty signalPowerInternal = new SimpleDoubleProperty();
    private final SimpleDoubleProperty noisePowerInternal = new SimpleDoubleProperty();
    private final SimpleDoubleProperty maxDataRateInternal = new SimpleDoubleProperty();
    
    public ShannonsPresenter(ShannonsTheorem model, ShannonsView view) {
        this.model = model;
        this.view = view;
        bindToModel();
        attachViewEvents();
    }
    
    private void bindToModel() {
        bandWidthInternal.bindBidirectional(model.bandWidthProperty());
        signalPowerInternal.bindBidirectional(model.signalPowerProperty());
        noisePowerInternal.bindBidirectional(model.noisePowerProperty());
        maxDataRateInternal.bindBidirectional(model.maxDataRate());
    }
    
    private void attachViewEvents() {
        view.bwField.textProperty().bindBidirectional(bandWidthInternal);
        view.spField.textProperty().bindBidirectional(signalPowerInternal);
        view.npField.textProperty().bindBidirectional(noisePowerInternal);
        view.mdrField.textProperty().bindBidirectional(maxDataRateInternal);
        view.calcButton.setOnAction(e -> saveData());
    }
    
    private void saveData() {
        boolean isSaved = model.save();
    }
}
