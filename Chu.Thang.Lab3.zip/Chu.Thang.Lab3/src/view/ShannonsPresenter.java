
package view;

import model.ShannonsTheorem;

import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.converter.NumberStringConverter;

/**
 *
 * @author vthan
 */
public class ShannonsPresenter {
    
    private final ShannonsTheorem model;
    private final ShannonsView view;
    
    private final SimpleDoubleProperty bandWidthInternal = new SimpleDoubleProperty();
    private final SimpleDoubleProperty signalPowerInternal = new SimpleDoubleProperty();
    private final SimpleDoubleProperty noisePowerInternal = new SimpleDoubleProperty();
    private final SimpleDoubleProperty maxDataRateInternal = new SimpleDoubleProperty();
    
    /**
     *
     * @param model
     * @param view
     */
    public ShannonsPresenter(ShannonsTheorem model, ShannonsView view) {
        this.model = model;
        this.view = view;
        bindToModel();
        attachViewEvents();
    }
    
    private void bindToModel() {
        bandWidthInternal.bindBidirectional(model.bandWidthProperty());
        signalPowerInternal.bindBidirectional(model.signalPowerProperty());
        noisePowerInternal.bindBidirectional(model.noisePowerProperty());
        maxDataRateInternal.bindBidirectional(model.maxDataRate());
    }
    
    private void attachViewEvents() {
        view.bwField.textProperty().bindBidirectional(bandWidthInternal, new NumberStringConverter());
        view.spField.textProperty().bindBidirectional(signalPowerInternal, new NumberStringConverter());
        view.npField.textProperty().bindBidirectional(noisePowerInternal, new NumberStringConverter());
        view.mdrField.textProperty().bindBidirectional(maxDataRateInternal, new NumberStringConverter());
        view.calcButton.setOnAction(e -> saveData());
        view.calcButton.setOnAction(e -> saveData());
    }
    
    private void saveData() {
        boolean isSaved = model.save();
    }
}
