/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

/**
 *
 * @author vthan
 */
public class ShannonsView extends GridPane {
    // Labels
    Label bwLabel = new Label("Bandwidth (Hertz/Hz): ");
    Label spLabel = new Label("Signal Power (W): ");
    Label npLabel = new Label("Noise Power (W): ");
    Label mdrLabel = new Label("Max Data Rate: ");
    
    // Fields
    TextField bwField = new TextField();
    TextField spField = new TextField();
    TextField npField = new TextField();
    TextField mdrField = new TextField();
    
    // Buttons
    Button calcButton = new Button("Calculate");
    
    public ShannonsView(){
        layoutForm();
    }
    
    private void layoutForm(){
        this.setHgap(10);
        this.setVgap(10);
        
        this.add(bwLabel, 1, 2);
        this.add(spLabel, 1, 3);
        this.add(npLabel, 1, 4);
        this.add(mdrLabel, 1, 5);
        
        this.add(bwField, 2, 2);
        this.add(spField, 2, 3);
        this.add(npField, 2, 4);
        this.add(mdrField, 2,5);
        
        // Add button
        VBox buttonBox = new VBox(calcButton);
        calcButton.setMaxWidth(Double.MAX_VALUE);
        this.add(buttonBox, 3,1,1,5);
    }
}
